var expect = require('chai').expect;
var mongoose = require('mongoose');
var Pokemon = require('../server/pokemon/Pokemon');

describe('Pokemon Model', function () {
  // TODO: Write tests here!
});