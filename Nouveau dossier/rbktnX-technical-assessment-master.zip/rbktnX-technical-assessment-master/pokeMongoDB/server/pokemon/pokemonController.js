var Pokemon = require('./Pokemon');

// TODO: Complete each of the following controller methods
exports.createOne = function (req, res) {
};

exports.retrieve = function (req, res) {
};

exports.retrieveOne = function (req, res) {
};

exports.updateOne = function (req, res) {
};

exports.deleteOne = function (req, res) {
};
