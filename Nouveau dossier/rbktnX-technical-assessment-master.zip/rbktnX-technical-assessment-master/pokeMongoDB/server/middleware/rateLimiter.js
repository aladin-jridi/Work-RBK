var rateLimiter = function (req, res, next) {
  // TODO: Implement your rate limiter here
};

module.exports = rateLimiter;
