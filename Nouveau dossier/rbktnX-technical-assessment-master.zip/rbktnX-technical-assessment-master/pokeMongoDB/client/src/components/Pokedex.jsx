import React from "react";

const Pokedex = (props) => (
  <div>
    <ul className="pokemon-list">
      <li className="pokemon-list-item">Pokemon 1</li>
      <li className="pokemon-list-item">Pokemon 2</li>
      <li className="pokemon-list-item">Pokemon 3</li>
      <li className="pokemon-list-item">Pokemon 4</li>
      <li className="pokemon-list-item">Pokemon 5</li>
      <li className="pokemon-list-item">Pokemon 6</li>
      <li className="pokemon-list-item">Pokemon 7</li>
      <li className="pokemon-list-item">Pokemon 8</li>
    </ul>
  </div>
);

export default Pokedex;
