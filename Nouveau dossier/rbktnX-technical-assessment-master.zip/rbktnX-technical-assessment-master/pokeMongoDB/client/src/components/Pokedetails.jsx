import React from 'react';

const Pokedetails = (props) => (
  <div>Pokemon details</div>
)

export default Pokedetails;
